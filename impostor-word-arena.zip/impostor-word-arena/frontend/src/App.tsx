import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Crown, Eye, Gamepad2, Lock, Megaphone, Music, Play, Plus, Send, Settings, Shield, Sparkles, Users, Vote, Volume2 } from 'lucide-react';
import './styles.css';

type TeamSize = 3|4|5|6|7|8|9|10;
type Phase = 'menu'|'browse'|'create'|'lobby'|'clues'|'vote'|'reveal'|'settings';
type PublicLobby = { id:string; name:string; public:boolean; hasPassword:boolean; players:number; maxPlayers:number; teamSize:TeamSize; impostors:number; phase:string; botsEnabled:boolean };
type Player = { id:string; name:string; avatar:string; bot:boolean; ready:boolean; team:'normal'|'impostor'|'unknown'; connected:boolean };
type ChatLine = { id:string; playerId:string; name:string; avatar:string; text:string; round:number; at:number; system?:boolean };
type RoomState = { roomId:string; phase:'lobby'|'clue'|'vote'|'reveal'|'ended'; config:any; players:Player[]; hostId:string; clueRound:number; turnIndex:number; chat:ChatLine[]; votes:Record<string,string>; result?:{winner:'normal'|'impostor'; impostors:string[]; word:string; eliminated:string[]} ; deadline?:number; self?:{id:string; role:'normal'|'impostor'; prompt:string} };

const API = import.meta.env.VITE_API_BASE || '';
const adjectives = ['Velvet','Cosmic','Neon','Golden','Lucky','Wild','Silent','Pixel','Nova','Crimson'];
const nouns = ['Fox','Mango','Otter','Comet','Panda','Raven','Tiger','Luna','Biscuit','Echo'];
const randomName = () => `${adjectives[Math.floor(Math.random()*adjectives.length)]}${nouns[Math.floor(Math.random()*nouns.length)]}`;
const avatarFor = (name:string) => `https://api.dicebear.com/9.x/bottts-neutral/svg?seed=${encodeURIComponent(name)}`;

function useSound(settings:{music:number;sfx:number;typing:boolean}) {
  const ctx = useRef<AudioContext|null>(null);
  const ensure = () => { if (!ctx.current) ctx.current = new AudioContext(); return ctx.current; };
  const beep = (freq:number, dur=0.05, gain=0.04) => {
    if (settings.sfx <= 0) return;
    const ac = ensure(); const osc = ac.createOscillator(); const g = ac.createGain();
    osc.frequency.value = freq; g.gain.value = gain * settings.sfx; osc.connect(g); g.connect(ac.destination); osc.start(); osc.stop(ac.currentTime + dur);
  };
  return {
    click:()=>beep(520,0.04,0.05), join:()=>beep(720,0.08,0.06), vote:()=>beep(240,0.12,0.07), win:()=>{beep(660,0.08,0.07); setTimeout(()=>beep(880,0.1,0.07),100)}, lose:()=>beep(150,0.28,0.08), type:()=> settings.typing && beep(900+Math.random()*260,0.018,0.018)
  };
}

function App(){
  const [phase,setPhase]=useState<Phase>('menu');
  const [name,setName]=useState(localStorage.playerName || randomName());
  const [lobbies,setLobbies]=useState<PublicLobby[]>([]);
  const [room,setRoom]=useState<RoomState|null>(null);
  const [ws,setWs]=useState<WebSocket|null>(null);
  const [password,setPassword]=useState('');
  const [clue,setClue]=useState('');
  const [settings,setSettings]=useState({music:.45,sfx:.7,typing:true,animations:true,fullscreen:false,language:'Coming soon',account:'Guest'});
  const [create,setCreate]=useState({name:'Friday Night Bluff', teamSize:5 as TeamSize, impostors:1, botsEnabled:true, public:true, password:'', roundDuration:45, votingDuration:30});
  const sound = useSound(settings);

  useEffect(()=>{ localStorage.playerName = name; },[name]);
  useEffect(()=>{ if(phase==='browse') refreshLobbies(); },[phase]);
  useEffect(()=>{ if(!ws) return; ws.onmessage=(ev)=>{ const msg=JSON.parse(ev.data); if(msg.type==='state'){ setRoom(msg.state); if(msg.state.phase==='clue') setPhase('clues'); if(msg.state.phase==='vote') setPhase('vote'); if(msg.state.phase==='reveal'||msg.state.phase==='ended') setPhase('reveal'); } if(msg.type==='sfx') (sound as any)[msg.name]?.(); }; return()=>ws.close(); },[ws]);

  async function refreshLobbies(){ const r=await fetch(`${API}/api/lobbies`); setLobbies(await r.json()); }
  async function createRoom(){ sound.click(); const r=await fetch(`${API}/api/rooms`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({...create, hostName:name, avatar:avatarFor(name)})}); const data=await r.json(); connect(data.roomId, create.password); }
  async function quickPlay(){ sound.click(); const r=await fetch(`${API}/api/matchmake`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name, avatar:avatarFor(name)})}); const data=await r.json(); connect(data.roomId, data.password || ''); }
  function connect(roomId:string, pass=''){ const protocol=location.protocol==='https:'?'wss':'ws'; const base=API ? API.replace(/^http/,'ws') : `${protocol}://${location.host}`; const sock=new WebSocket(`${base}/ws/${roomId}?name=${encodeURIComponent(name)}&avatar=${encodeURIComponent(avatarFor(name))}&password=${encodeURIComponent(pass)}`); setWs(sock); setPhase('lobby'); }
  function send(type:string,payload:any={}){ ws?.send(JSON.stringify({type,...payload})); }
  function submitClue(){ if(!clue.trim())return; sound.type(); send('clue',{text:clue.trim().slice(0,36)}); setClue(''); }
  function vote(id:string){ sound.vote(); send('vote',{targetId:id}); }
  function ready(){ sound.click(); send('ready'); }
  function start(){ sound.click(); send('start'); }
  function botFill(){ send('fillBots'); }

  const me = room?.self?.id;
  const currentTurn = room?.players[room.turnIndex];
  const isMyTurn = currentTurn?.id===me;
  const deadline = useCountdown(room?.deadline);

  return <div className={`app ${settings.animations?'motion-on':'motion-off'}`}>
    <AmbientOrbs />
    <div className="topbar"><div className="brand"><Shield/><span>Impostor Word Arena</span></div><div className="profile"><img src={avatarFor(name)}/><input value={name} onChange={e=>setName(e.target.value.slice(0,18))}/><button onClick={()=>setPhase('settings')}><Settings size={18}/></button></div></div>
    <AnimatePresence mode="wait">
      {phase==='menu' && <Screen key="menu"><Hero quickPlay={quickPlay} setPhase={setPhase}/></Screen>}
      {phase==='browse' && <Screen key="browse"><LobbyBrowser lobbies={lobbies} refresh={refreshLobbies} join={(l)=>{ if(l.hasPassword){ const p=prompt('Private lobby password')||''; connect(l.id,p);} else connect(l.id); }} create={()=>setPhase('create')}/></Screen>}
      {phase==='create' && <Screen key="create"><Creator create={create} setCreate={setCreate} submit={createRoom} back={()=>setPhase('menu')}/></Screen>}
      {phase==='lobby' && room && <Screen key="lobby"><Lobby room={room} me={me} ready={ready} start={start} botFill={botFill}/></Screen>}
      {phase==='clues' && room && <Screen key="clues"><Clues room={room} me={me} isMyTurn={isMyTurn} currentTurn={currentTurn} clue={clue} setClue={setClue} submit={submitClue} countdown={deadline}/></Screen>}
      {phase==='vote' && room && <Screen key="vote"><Voting room={room} me={me} vote={vote} countdown={deadline}/></Screen>}
      {phase==='reveal' && room && <Screen key="reveal"><Reveal room={room} sound={sound}/></Screen>}
      {phase==='settings' && <Screen key="settings"><SettingsPanel settings={settings} setSettings={setSettings} back={()=>setPhase('menu')}/></Screen>}
    </AnimatePresence>
  </div>
}
function Screen({children}:{children:React.ReactNode}){return <motion.main initial={{opacity:0,y:24,scale:.98}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:-20,scale:.98}} transition={{duration:.32}}>{children}</motion.main>}
function AmbientOrbs(){return <><div className="orb one"/><div className="orb two"/><div className="orb three"/></>}
function Hero({quickPlay,setPhase}:any){return <section className="hero"><div className="hero-card"><div className="badge"><Sparkles size={16}/> Live party deduction</div><h1>Blend in. Bluff hard. Find the impostor.</h1><p>Two clue rounds, one secret word, suspiciously clever bots, cinematic voting, and instant 3v3–10v10 matchmaking.</p><div className="hero-actions"><button className="primary" onClick={quickPlay}><Play/> Quick Play</button><button onClick={()=>setPhase('browse')}><Users/> Lobby Browser</button><button onClick={()=>setPhase('create')}><Plus/> Host Custom Match</button></div></div><div className="phone"><div className="chat-preview"><p><b>NovaPanda</b> says “crunchy”</p><p><b>PixelFox</b> says “orchard”</p><p className="sus"><b>VelvetOtter</b> says “vegetable?”</p></div><div className="vote-pulse"><Vote/> Vote starts in 03</div></div></section>}
function LobbyBrowser({lobbies,refresh,join,create}:any){return <section className="panel"><div className="panel-head"><h2>Public Lobbies</h2><div><button onClick={refresh}>Refresh</button><button className="primary" onClick={create}><Plus/> Create</button></div></div><div className="lobby-grid">{lobbies.map((l:PublicLobby)=><button className="lobby-card" key={l.id} onClick={()=>join(l)}><div><h3>{l.name}</h3><span>{l.phase} · {l.players}/{l.maxPlayers}</span></div><div className="chips"><span>{l.teamSize}v{l.teamSize}</span><span><Eye size={14}/>{l.impostors}</span>{l.hasPassword&&<span><Lock size={14}/>Private</span>}{l.botsEnabled&&<span><Bot size={14}/>Bots</span>}</div></button>)}</div>{!lobbies.length&&<div className="empty">No public rooms found. Quick Play can create a bot-seeded room instantly.</div>}</section>}
function Creator({create,setCreate,submit,back}:any){ const set=(k:string,v:any)=>setCreate((c:any)=>({...c,[k]:v})); return <section className="panel creator"><div className="panel-head"><h2>Party Creator</h2><button onClick={back}>Back</button></div><label>Lobby Name<input value={create.name} onChange={e=>set('name',e.target.value)}/></label><div className="form-grid"><label>Team Size<select value={create.teamSize} onChange={e=>set('teamSize',+e.target.value)}>{[3,4,5,6,7,8,9,10].map(n=><option key={n} value={n}>{n}v{n} · {n*2} players</option>)}</select></label><label>Impostors<select value={create.impostors} onChange={e=>set('impostors',+e.target.value)}>{[1,2,3,4,5].map(n=><option key={n} value={n}>{n}</option>)}</select></label><label>Round Duration<input type="range" min="20" max="90" value={create.roundDuration} onChange={e=>set('roundDuration',+e.target.value)}/><b>{create.roundDuration}s</b></label><label>Voting Duration<input type="range" min="15" max="60" value={create.votingDuration} onChange={e=>set('votingDuration',+e.target.value)}/><b>{create.votingDuration}s</b></label></div><div className="switch-row"><button className={create.public?'active':''} onClick={()=>set('public',true)}><Megaphone/> Public</button><button className={!create.public?'active':''} onClick={()=>set('public',false)}><Lock/> Private</button><button className={create.botsEnabled?'active':''} onClick={()=>set('botsEnabled',!create.botsEnabled)}><Bot/> Auto-fill Bots</button></div>{!create.public&&<label>Password<input type="password" value={create.password} onChange={e=>set('password',e.target.value)} placeholder="Required for invited users"/></label>}<button className="primary wide" onClick={submit}><Gamepad2/> Create Lobby</button></section>}
function Lobby({room,me,ready,start,botFill}:any){const host=room.hostId===me; return <section className="panel"><div className="panel-head"><h2>{room.config.name}</h2><div className="chips"><span>{room.config.teamSize}v{room.config.teamSize}</span><span>{room.config.public?'Public':'Private'}</span><span>{room.config.impostors} impostor(s)</span></div></div><div className="players">{room.players.map((p:Player)=><div className="player" key={p.id}><img src={p.avatar}/><b>{p.name}</b>{p.id===room.hostId&&<Crown size={16}/>} {p.bot&&<Bot size={16}/>}<span className={p.ready?'ready':'waiting'}>{p.ready?'Ready':'Waiting'}</span></div>)}</div><div className="hero-actions"><button onClick={ready}>Ready Up</button>{host&&<button onClick={botFill}><Bot/> Fill Empty Slots</button>}{host&&<button className="primary" onClick={start}><Play/> Start Match</button>}</div></section>}
function Clues({room,me,isMyTurn,currentTurn,clue,setClue,submit,countdown}:any){return <section className="game"><aside className="side-card"><h3>Your Role</h3><div className={`role ${room.self.role}`}>{room.self.role==='impostor'?'IMPOSTOR':'WORD KEEPER'}</div><p>{room.self.prompt}</p><div className="timer">{countdown}s</div></aside><section className="chat"><div className="turn-banner"><span className="pulse"/> Round {room.clueRound}/2 · {currentTurn?.name}'s clue</div><div className="messages">{room.chat.map((m:ChatLine)=><div className="msg" key={m.id}><img src={m.avatar}/><div><b>{m.name}</b><p>{m.text}</p></div></div>)}</div><div className={`composer ${isMyTurn?'hot':''}`}><input disabled={!isMyTurn} value={clue} onChange={e=>setClue(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')submit()}} placeholder={isMyTurn?'Type one clue word or short phrase':'Waiting for your turn...'}/><button disabled={!isMyTurn} onClick={submit}><Send/></button></div></section><aside className="side-card"><h3>Players</h3>{room.players.map((p:Player,i:number)=><div className={`mini ${room.turnIndex===i?'current':''}`} key={p.id}><img src={p.avatar}/>{p.name}{p.bot&&<Bot size={13}/>}</div>)}</aside></section>}
function Voting({room,me,vote,countdown}:any){return <section className="panel vote"><h2>Who is the impostor?</h2><div className="timer big">{countdown}</div><div className="vote-grid">{room.players.map((p:Player)=><button key={p.id} onClick={()=>vote(p.id)} className={room.votes[me||'']===p.id?'selected':''}><img src={p.avatar}/><b>{p.name}</b><span>{Object.values(room.votes).filter(v=>v===p.id).length} votes</span></button>)}</div></section>}
function Reveal({room,sound}:any){useEffect(()=>{room.result?.winner==='normal'?sound.win():sound.lose()},[]); return <section className="reveal"><motion.div initial={{scale:.7,opacity:0}} animate={{scale:1,opacity:1}}><h1>{room.result?.winner==='normal'?'Word Keepers Win':'Impostors Win'}</h1><p>The word was <b>{room.result?.word}</b></p><div className="players">{room.players.map((p:Player)=><div className={`player ${room.result?.impostors.includes(p.id)?'impostor-glow':''}`} key={p.id}><img src={p.avatar}/><b>{p.name}</b><span>{room.result?.impostors.includes(p.id)?'Impostor':'Normal'}</span></div>)}</div></motion.div></section>}
function SettingsPanel({settings,setSettings,back}:any){const set=(k:string,v:any)=>setSettings((s:any)=>({...s,[k]:v})); return <section className="panel settings"><div className="panel-head"><h2>Settings</h2><button onClick={back}>Done</button></div><label><Music/> Music Volume<input type="range" min="0" max="1" step=".01" value={settings.music} onChange={e=>set('music',+e.target.value)}/></label><label><Volume2/> Sound Effects<input type="range" min="0" max="1" step=".01" value={settings.sfx} onChange={e=>set('sfx',+e.target.value)}/></label><div className="switch-row"><button className={settings.typing?'active':''} onClick={()=>set('typing',!settings.typing)}>Typing Sounds</button><button className={settings.animations?'active':''} onClick={()=>set('animations',!settings.animations)}>Animations</button><button onClick={()=>document.documentElement.requestFullscreen?.()}>Fullscreen</button></div><div className="placeholder">Language settings and account settings are wired as product placeholders for localization/auth integration.</div></section>}
function useCountdown(deadline?:number){const [n,setN]=useState(0); useEffect(()=>{const t=setInterval(()=>setN(Math.max(0,Math.ceil(((deadline||0)-Date.now())/1000))),250); return()=>clearInterval(t)},[deadline]); return n}

createRoot(document.getElementById('root')!).render(<App/>);
