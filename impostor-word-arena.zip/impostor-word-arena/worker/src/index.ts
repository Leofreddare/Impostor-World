type Env = {
  ROOMS: DurableObjectNamespace;
  LOBBY_INDEX: KVNamespace;
  POLLINATIONS_TEXT_ENDPOINT: string;
  BOT_MAINTENANCE_ROOM_COUNT: string;
  CORS_ORIGIN: string;
};
type TeamSize = 3|4|5|6|7|8|9|10;
type Player = { id:string; name:string; avatar:string; bot:boolean; ready:boolean; team:'normal'|'impostor'|'unknown'; connected:boolean; secret?:string; salt?:string; passHash?:string };
type Config = { name:string; teamSize:TeamSize; impostors:number; botsEnabled:boolean; public:boolean; password?:string; passwordHash?:string; roundDuration:number; votingDuration:number; hostName:string; avatar:string };
type RoomState = { roomId:string; phase:'lobby'|'clue'|'vote'|'reveal'|'ended'; config:Config; players:Player[]; hostId:string; clueRound:number; turnIndex:number; chat:any[]; votes:Record<string,string>; result?:any; deadline?:number; word?:string; category?:string };
const WORDS = [
  {word:'pineapple', category:'tropical fruit', normal:['sweet','spiky','yellow','pizza','island','rings'], imp:['fruit','food','summer']},
  {word:'volcano', category:'natural disaster', normal:['lava','eruption','ash','mountain','magma','island'], imp:['nature','danger','hot']},
  {word:'library', category:'quiet public place', normal:['books','shelves','whisper','cards','study','stacks'], imp:['building','quiet','learning']},
  {word:'telescope', category:'science tool', normal:['stars','lens','astronomy','moon','orbit','observatory'], imp:['science','sky','glass']},
  {word:'saxophone', category:'musical instrument', normal:['jazz','brass','reed','solo','smooth','horn'], imp:['music','stage','sound']},
  {word:'snowman', category:'winter thing', normal:['carrot','frost','coal','melt','scarf','yard'], imp:['cold','season','outside']}
];
const botNames = ['CircuitMango','NovaOtter','VelvetBot','PixelPanda','EchoRaven','TurboLuna','LuckyComet','GoldenFox','SilentTiger','CrimsonBiscuit'];
const json = (body:any, status=200, env?:Env) => new Response(JSON.stringify(body), {status, headers:{'content-type':'application/json','access-control-allow-origin':env?.CORS_ORIGIN || '*','access-control-allow-headers':'content-type'}});
const uid = () => crypto.randomUUID();
const now = () => Date.now();
async function sha256(input:string){ const bytes = new TextEncoder().encode(input); const hash = await crypto.subtle.digest('SHA-256', bytes); return [...new Uint8Array(hash)].map(b=>b.toString(16).padStart(2,'0')).join(''); }
async function hashPassword(password:string, salt=uid()){ return {salt, hash: await sha256(`${salt}:${password}`)}; }
async function verifyPassword(password:string, salt:string, hash:string){ return (await sha256(`${salt}:${password}`)) === hash; }
function publicRoom(s:RoomState){ return { id:s.roomId, name:s.config.name, public:s.config.public, hasPassword:!!s.config.passwordHash, players:s.players.length, maxPlayers:s.config.teamSize*2, teamSize:s.config.teamSize, impostors:s.config.impostors, phase:s.phase, botsEnabled:s.config.botsEnabled }; }

export default {
  async fetch(req:Request, env:Env, ctx:ExecutionContext){
    if(req.method==='OPTIONS') return new Response(null,{headers:{'access-control-allow-origin':env.CORS_ORIGIN,'access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'content-type'}});
    const url = new URL(req.url);
    try {
      if(url.pathname==='/api/lobbies'){
        const list = await env.LOBBY_INDEX.list({prefix:'public:'});
        const rooms:any[]=[];
        for(const k of list.keys){ const v=await env.LOBBY_INDEX.get(k.name,'json'); if(v) rooms.push(v); }
        return json(rooms,200,env);
      }
      if(url.pathname==='/api/rooms' && req.method==='POST'){
        const body:any = await req.json();
        const id = uid(); const obj = env.ROOMS.get(env.ROOMS.idFromName(id));
        const init = await obj.fetch('https://room/init',{method:'POST',body:JSON.stringify({...body, roomId:id})});
        return json(await init.json(), init.status, env);
      }
      if(url.pathname==='/api/matchmake' && req.method==='POST'){
        const body:any = await req.json();
        const list = await env.LOBBY_INDEX.list({prefix:'public:'});
        let best:any=null;
        for(const k of list.keys){ const lobby:any=await env.LOBBY_INDEX.get(k.name,'json'); if(lobby && lobby.phase==='lobby' && !lobby.hasPassword && lobby.players<lobby.maxPlayers){ best=lobby; break; } }
        if(!best){ const id=uid(); const obj=env.ROOMS.get(env.ROOMS.idFromName(id)); await obj.fetch('https://room/init',{method:'POST',body:JSON.stringify({roomId:id,name:'Instant Bluff Table',teamSize:5,impostors:1,botsEnabled:true,public:true,roundDuration:45,votingDuration:30,hostName:body.name,avatar:body.avatar})}); best={id}; }
        return json({roomId:best.id},200,env);
      }
      if(url.pathname.startsWith('/ws/')){
        const id = url.pathname.split('/').pop()!; const obj = env.ROOMS.get(env.ROOMS.idFromName(id)); return obj.fetch(req);
      }
      return json({ok:true,name:'Impostor Word Arena API'},200,env);
    } catch(e:any){ return json({error:e.message || 'Server error'},500,env); }
  },
  async scheduled(_:ScheduledEvent, env:Env){
    const desired = Number(env.BOT_MAINTENANCE_ROOM_COUNT || 4);
    const list = await env.LOBBY_INDEX.list({prefix:'public:'});
    const active = list.keys.length;
    for(let i=active;i<desired;i++){
      const id=uid(); const obj=env.ROOMS.get(env.ROOMS.idFromName(id));
      await obj.fetch('https://room/init',{method:'POST',body:JSON.stringify({roomId:id,name:`Bot Table ${i+1}`,teamSize:([3,4,5,6] as number[])[i%4],impostors:1,botsEnabled:true,public:true,roundDuration:45,votingDuration:30,hostName:'BotHost',avatar:botAvatar('BotHost'),botHost:true})});
    }
  }
};

export class RoomObject implements DurableObject {
  state: DurableObjectState; env:Env; mem?:RoomState;
  constructor(state:DurableObjectState, env:Env){ this.state=state; this.env=env; }
  async fetch(req:Request){
    const url=new URL(req.url);
    if(url.pathname==='/init') return this.init(await req.json());
    if(req.headers.get('upgrade')==='websocket') return this.connect(req);
    return json(await this.load());
  }
  async init(body:any){
    const roomId = body.roomId; const password = String(body.password || '');
    const hp = password ? await hashPassword(password) : null;
    const config:Config = { name:String(body.name || 'Bluff Room'), teamSize:clampTeam(body.teamSize), impostors:Math.max(1,Math.min(Number(body.impostors)||1, Math.floor(clampTeam(body.teamSize)*2/3))), botsEnabled:!!body.botsEnabled, public:!!body.public, roundDuration:Math.max(20,Math.min(90,Number(body.roundDuration)||45)), votingDuration:Math.max(15,Math.min(60,Number(body.votingDuration)||30)), hostName:String(body.hostName || 'Host'), avatar:String(body.avatar || botAvatar('Host')), passwordHash:hp?.hash, password:hp?.salt };
    const host:Player={id:uid(),name:config.hostName,avatar:config.avatar,bot:!!body.botHost,ready:!!body.botHost,team:'unknown',connected:false};
    const s:RoomState={roomId,phase:'lobby',config,players:[host],hostId:host.id,clueRound:1,turnIndex:0,chat:[],votes:{}};
    this.mem=s; await this.save(); await this.index();
    if(config.botsEnabled && body.botHost) await this.fillBots();
    return json({roomId, hostId:host.id});
  }
  async connect(req:Request){
    const s=await this.load(); const url=new URL(req.url);
    if(s.config.passwordHash){ const pass=url.searchParams.get('password')||''; if(!await verifyPassword(pass, s.config.password!, s.config.passwordHash)) return new Response('Bad password',{status:403}); }
    const pair=new WebSocketPair(); const [client,server]=Object.values(pair);
    const name=(url.searchParams.get('name')||'Guest').slice(0,18); const avatar=url.searchParams.get('avatar') || botAvatar(name);
    let p=s.players.find(x=>!x.bot && x.name===name);
    if(!p && s.players.length < s.config.teamSize*2){ p={id:uid(),name,avatar,bot:false,ready:false,team:'unknown',connected:true}; s.players.push(p); }
    else if(p){ p.connected=true; p.avatar=avatar; }
    else return new Response('Full',{status:409});
    server.serializeAttachment({playerId:p.id}); this.state.acceptWebSocket(server); await this.save(); await this.index(); this.sendState();
    return new Response(null,{status:101,webSocket:client});
  }
  async webSocketMessage(ws:WebSocket, message:string|ArrayBuffer){
    const att:any=ws.deserializeAttachment(); const playerId=att?.playerId; const msg=JSON.parse(String(message));
    const s=await this.load(); const p=s.players.find(x=>x.id===playerId); if(!p || p.bot) return;
    if(msg.type==='ready'){ p.ready=!p.ready; await this.save(); this.sendState(); }
    if(msg.type==='fillBots' && playerId===s.hostId){ await this.fillBots(); }
    if(msg.type==='start' && playerId===s.hostId){ await this.startGame(); }
    if(msg.type==='clue'){ await this.submitClue(playerId, String(msg.text||'')); }
    if(msg.type==='vote'){ await this.castVote(playerId, String(msg.targetId||'')); }
  }
  async webSocketClose(ws:WebSocket){ const att:any=ws.deserializeAttachment(); const s=await this.load(); const p=s.players.find(x=>x.id===att?.playerId); if(p){p.connected=false; await this.save(); await this.index(); this.sendState();} }
  async alarm(){ const s=await this.load(); if(s.phase==='clue'){ await this.botTurns(); if(s.deadline && now()>s.deadline) await this.forceAdvanceTurn(); } if(s.phase==='vote' && s.deadline && now()>s.deadline) await this.finishVote(); await this.state.storage.setAlarm(Date.now()+2500); }
  async load(){ if(this.mem) return this.mem; this.mem = await this.state.storage.get<RoomState>('state') as RoomState; if(!this.mem) throw new Error('Room not initialized'); return this.mem; }
  async save(){ if(this.mem) await this.state.storage.put('state', this.mem); }
  async index(){ const s=await this.load(); if(s.config.public) await this.env.LOBBY_INDEX.put(`public:${s.roomId}`, JSON.stringify(publicRoom(s)), {expirationTtl:3600}); }
  sendState(){ const s=this.mem!; for(const ws of this.state.getWebSockets()){ const a:any=ws.deserializeAttachment(); const p=s.players.find(x=>x.id===a?.playerId); ws.send(JSON.stringify({type:'state',state:sanitized(s,p)})); } }
  async fillBots(){ const s=await this.load(); const max=s.config.teamSize*2; while(s.players.length<max){ const name=uniqueBotName(s); s.players.push({id:uid(),name,avatar:botAvatar(name),bot:true,ready:true,team:'unknown',connected:true}); } await this.save(); await this.index(); this.sendState(); }
  async startGame(){ const s=await this.load(); if(s.config.botsEnabled) await this.fillBots(); if(s.players.length<6) return; const pack=WORDS[Math.floor(Math.random()*WORDS.length)]; s.word=pack.word; s.category=pack.category; s.phase='clue'; s.chat=[]; s.votes={}; s.clueRound=1; s.turnIndex=0; s.result=undefined; const shuffled=[...s.players].sort(()=>Math.random()-.5); const imps=new Set(shuffled.slice(0,s.config.impostors).map(p=>p.id)); s.players.forEach(p=>p.team=imps.has(p.id)?'impostor':'normal'); s.deadline=now()+s.config.roundDuration*1000; await this.save(); await this.index(); await this.state.storage.setAlarm(Date.now()+1500); this.sendState(); }
  async submitClue(playerId:string, text:string){ const s=await this.load(); if(s.phase!=='clue' || s.players[s.turnIndex]?.id!==playerId) return; text=text.replace(/[\n\r]/g,' ').trim().slice(0,36); if(!text) return; const p=s.players.find(x=>x.id===playerId)!; s.chat.push({id:uid(),playerId:p.id,name:p.name,avatar:p.avatar,text,round:s.clueRound,at:now()}); await this.advanceTurn(); }
  async forceAdvanceTurn(){ const s=await this.load(); const p=s.players[s.turnIndex]; const fallback = p.team==='impostor' ? 'interesting' : 'related'; await this.submitClue(p.id, fallback); }
  async advanceTurn(){ const s=await this.load(); s.turnIndex++; if(s.turnIndex>=s.players.length){ s.turnIndex=0; s.clueRound++; } if(s.clueRound>2){ s.phase='vote'; s.deadline=now()+s.config.votingDuration*1000; } else s.deadline=now()+s.config.roundDuration*1000; await this.save(); this.sendState(); await this.botTurns(); }
  async botTurns(){ const s=await this.load(); if(s.phase!=='clue') return; let guard=0; while(s.players[s.turnIndex]?.bot && guard++<s.players.length){ const bot=s.players[s.turnIndex]; const clue=await this.botClue(bot); await this.submitClue(bot.id, clue); } if(s.phase==='vote'){ await this.botVotes(); } }
  async botClue(bot:Player){ const s=await this.load(); const used=s.chat.map(c=>c.text).join(', '); const role=bot.team; const prompt = role==='impostor' ? `You are an impostor in a word guessing game. Exact word is hidden. Category/hint: ${s.category}. Used clues: ${used}. Give one believable clue word or short phrase, not too obvious. Return only the clue.` : `Secret word: ${s.word}. Category: ${s.category}. Used clues: ${used}. Give one subtle clue word or short phrase that relates to the secret word but does not reveal it directly. Return only the clue.`;
    try { return clean(await pollinate(this.env, [{role:'system',content:'You are a clever social deduction party game bot. Be concise and natural.'},{role:'user',content:prompt}])); }
    catch { const pack=WORDS.find(w=>w.word===s.word)!; const arr=role==='impostor'?pack.imp:pack.normal; return arr[Math.floor(Math.random()*arr.length)]; }
  }
  async castVote(playerId:string,targetId:string){ const s=await this.load(); if(s.phase!=='vote' || !s.players.some(p=>p.id===targetId)) return; s.votes[playerId]=targetId; await this.save(); this.sendState(); if(Object.keys(s.votes).length>=s.players.length) await this.finishVote(); }
  async botVotes(){ const s=await this.load(); for(const b of s.players.filter(p=>p.bot && !s.votes[p.id])){ const target = chooseBotVote(s,b); s.votes[b.id]=target; } await this.save(); this.sendState(); if(Object.keys(s.votes).length>=s.players.length) await this.finishVote(); }
  async finishVote(){ const s=await this.load(); if(s.phase!=='vote') return; await this.botVotes(); const counts:Record<string,number>={}; Object.values(s.votes).forEach(id=>counts[id]=(counts[id]||0)+1); const ranked=Object.entries(counts).sort((a,b)=>b[1]-a[1]); const eliminated = ranked.slice(0,s.config.impostors).map(([id])=>id); const impostors=s.players.filter(p=>p.team==='impostor').map(p=>p.id); const allOut=impostors.every(id=>eliminated.includes(id)); s.phase='reveal'; s.result={winner:allOut?'normal':'impostor',impostors,word:s.word,eliminated}; await this.save(); await this.index(); this.sendState(); }
}
function sanitized(s:RoomState, self?:Player){ const copy=JSON.parse(JSON.stringify(s)); delete copy.word; delete copy.category; copy.config.password=undefined; copy.config.passwordHash=undefined; copy.players.forEach((p:any)=>{ p.team = copy.phase==='reveal'||copy.phase==='ended'?p.team:'unknown'; delete p.secret; delete p.salt; delete p.passHash; }); copy.self = self ? {id:self.id, role:self.team, prompt:self.team==='impostor'?`You only know the category: ${s.category}. Blend in.`:`Secret word: ${s.word}. Give subtle clues.`} : undefined; return copy; }
function clampTeam(v:any):TeamSize{ const n=Number(v); return ([3,4,5,6,7,8,9,10].includes(n)?n:5) as TeamSize; }
function botAvatar(name:string){ return `https://api.dicebear.com/9.x/bottts-neutral/svg?seed=${encodeURIComponent(name)}`; }
function uniqueBotName(s:RoomState){ let n=botNames[Math.floor(Math.random()*botNames.length)]; while(s.players.some(p=>p.name===n)) n += Math.floor(Math.random()*99); return n; }
function clean(t:string){ return t.replace(/^['"`]+|['"`.]+$/g,'').split('\n')[0].slice(0,36) || 'related'; }
function chooseBotVote(s:RoomState,b:Player){ const humans=s.players.filter(p=>p.id!==b.id); const suspicious=humans.map(p=>({p,score:(p.team==='impostor'?0.55:0.2)+Math.random()*0.45})).sort((a,b)=>b.score-a.score); return suspicious[0].p.id; }
async function pollinate(env:Env, messages:{role:string;content:string}[]){ const r=await fetch(env.POLLINATIONS_TEXT_ENDPOINT,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages, model:'openai', temperature:0.8, max_tokens:24})}); if(!r.ok) throw new Error('Pollinations failed'); const txt=await r.text(); try { const j=JSON.parse(txt); return j.choices?.[0]?.message?.content || j.text || txt; } catch { return txt; } }
