# Impostor Word Arena

A polished online multiplayer social-deduction starter project for an “Impostor Word Guessing” party game.

## What is included

- Premium animated React/Vite frontend.
- Cloudflare Worker API.
- Durable Object room authority with WebSocket Hibernation.
- Public lobby browser backed by Workers KV.
- Private password-protected lobbies.
- Host-configurable custom matches: 3v3 through 10v10, impostor count, bot filling, public/private, passwords, round duration, voting duration.
- Authoritative server-side role assignment, clue turns, voting, and reveal.
- AI bots that create/join/fill public rooms, submit clues, and vote.
- Pollinations.ai text generation integration using a public-code-safe POST request with `messages: [{ role, content }]`.
- Cloudflare cron-triggered bot-room maintenance.
- Synthetic sound-design hooks in the frontend: clicks, typing, vote confirmations, win/lose stingers.

## Repository layout

```txt
impostor-word-arena/
  package.json
  frontend/
    package.json
    index.html
    vite.config.ts
    src/App.tsx
    src/styles.css
  worker/
    package.json
    wrangler.jsonc
    tsconfig.json
    src/index.ts
```

## Local development

```bash
npm install
npm run worker:dev
npm run dev
```

By default, the frontend uses same-origin API calls. For local split development, create `frontend/.env.local`:

```bash
VITE_API_BASE=http://127.0.0.1:8787
```

Then run:

```bash
npm run worker:dev
npm run dev
```

## Cloudflare infrastructure design

### Worker

The Worker is the stateless public API edge:

- `GET /api/lobbies` returns indexed public rooms.
- `POST /api/rooms` creates a custom room.
- `POST /api/matchmake` finds an open public room or creates a bot-fillable room.
- `GET /ws/:roomId` upgrades to WebSocket and proxies to the room Durable Object.
- Scheduled cron runs every two minutes and creates bot-hosted public rooms when the lobby browser is sparse.

### Durable Objects

Each room is one Durable Object instance. The Durable Object owns all authoritative game state:

- lobby configuration
- connected players
- bot players
- private password verification
- role assignment
- selected secret word/category
- clue turns
- voting
- reveal and win calculation

Clients are never trusted for roles, secret word, impostor identity, vote totals, timers, or final result. Clients only send intents such as `ready`, `start`, `clue`, and `vote`.

### Workers KV

Workers KV stores a lightweight public lobby index with keys like:

```txt
public:<roomId>
```

The KV value contains only safe public metadata: room name, room ID, team size, player count, max players, bot setting, phase, impostor count, and whether a password exists. Password hashes and game secrets are never stored in KV.

### Password-protected private lobbies

Private lobbies do not appear in the public lobby browser. Passwords are never stored as plaintext. The Worker hashes the password with a per-room salt and stores only the hash and salt inside the Durable Object state. Clients must supply the password when opening the WebSocket connection.

For a stricter production hardening pass, replace the included SHA-256 helper with PBKDF2 or Argon2id via a trusted server-side implementation, add per-IP rate limits, and enforce authenticated users.

### Pollinations.ai bot AI

Bots call Pollinations from the server only:

```ts
await fetch(env.POLLINATIONS_TEXT_ENDPOINT, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    messages: [
      { role: 'system', content: 'You are a clever social deduction party game bot.' },
      { role: 'user', content: prompt }
    ],
    model: 'openai',
    temperature: 0.8,
    max_tokens: 24
  })
});
```

No private API key is included or required by this starter. If Pollinations introduces required credentials for your chosen production tier, store them as Cloudflare Worker secrets and never commit them.

## Create Cloudflare resources

### 1. Install Wrangler and log in

```bash
npm install
npx wrangler login
```

### 2. Create KV namespace

```bash
cd worker
npx wrangler kv namespace create LOBBY_INDEX
npx wrangler kv namespace create LOBBY_INDEX --preview
```

Copy the returned IDs into `worker/wrangler.jsonc`:

```jsonc
"kv_namespaces": [
  { "binding": "LOBBY_INDEX", "id": "YOUR_PRODUCTION_ID", "preview_id": "YOUR_PREVIEW_ID" }
]
```

### 3. Durable Object binding and migration

`worker/wrangler.jsonc` already contains:

```jsonc
"durable_objects": {
  "bindings": [
    { "name": "ROOMS", "class_name": "RoomObject" }
  ]
},
"migrations": [
  { "tag": "v1", "new_sqlite_classes": ["RoomObject"] }
]
```

Deploying the Worker applies the Durable Object migration.

### 4. Environment variables

`worker/wrangler.jsonc` includes non-secret defaults:

```jsonc
"vars": {
  "POLLINATIONS_TEXT_ENDPOINT": "https://text.pollinations.ai/openai",
  "BOT_MAINTENANCE_ROOM_COUNT": "6",
  "CORS_ORIGIN": "*"
}
```

For production, set `CORS_ORIGIN` to your frontend domain, for example:

```jsonc
"CORS_ORIGIN": "https://play.example.com"
```

If you later add secrets:

```bash
npx wrangler secret put SOME_SECRET_NAME
```

Do not commit `.dev.vars`, `.env`, API keys, tokens, or production passwords.

### 5. Deploy the Worker

```bash
cd worker
npx wrangler deploy
```

After deploy, your API will be available at a `workers.dev` URL unless you attach a custom route/domain.

### 6. Optional custom domain/route

In Cloudflare Dashboard:

1. Go to **Workers & Pages**.
2. Select `impostor-word-arena-api`.
3. Add a route such as `api.example.com/*` or `example.com/api/*`.
4. Update frontend `VITE_API_BASE` to the deployed API origin.

## Deploy frontend

### Option A: Cloudflare Pages

```bash
cd frontend
npm install
npm run build
```

Create a Cloudflare Pages project:

- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`
- Environment variable: `VITE_API_BASE=https://YOUR-WORKER-DOMAIN`

### Option B: Any static host

Build the app and upload `frontend/dist` to your preferred static hosting service. Set `VITE_API_BASE` at build time.

## Multiplayer connection flow

1. Frontend creates or selects a room.
2. Frontend opens a WebSocket connection:

```ts
new WebSocket(`${apiBase.replace(/^http/, 'ws')}/ws/${roomId}?name=...&avatar=...&password=...`)
```

3. Worker routes `/ws/:roomId` to the correct Durable Object using `idFromName(roomId)`.
4. Durable Object validates room password, accepts the WebSocket with Hibernation, attaches the `playerId`, and broadcasts sanitized state.
5. Each client receives only its own role prompt. The exact word is visible only to normal players and only inside their personal sanitized payload. Impostors receive only the category/hint.

## Game rules implemented server-side

1. Host chooses match settings.
2. Bots fill empty slots when enabled.
3. Server selects a secret word and category.
4. Server randomly assigns impostors.
5. Normal players receive the exact word.
6. Impostors receive only the category/hint.
7. Two clue rounds are enforced by the room Durable Object.
8. The server advances turns and timers.
9. Voting is counted server-side.
10. If every impostor is eliminated, normal players win. If at least one impostor survives, impostors win.

## Bot behavior

Bots can:

- host public rooms via scheduled Worker cron
- fill empty seats when auto-fill is enabled
- submit clue words/short phrases
- vote during the voting phase
- make imperfect decisions to avoid robotic play

The included bot voting logic blends randomness with suspicion scoring. The clue generation first tries Pollinations and falls back to local word-pack hints if the AI call fails.

## Production hardening checklist

Before public launch, add:

- real authentication/session tokens
- rate limiting for room creation, WebSocket connections, voting, and password attempts
- profanity/PII filtering for names and chat clues
- persistent profiles/accounts using D1
- analytics/events table in D1
- R2-hosted audio assets instead of synthesized placeholder sounds
- moderation tools
- bot prompt/version telemetry
- reconnect tokens so reloads preserve player identity
- anti-collusion/reporting UX
- E2E tests for role secrecy and vote integrity
- load tests for WebSocket concurrency

## D1 and R2 recommendations

This starter does not require D1 or R2 to run. Add them when you need persistent user profiles, progression, cosmetics, match history, moderation logs, or hosted media.

Suggested D1 tables:

```sql
CREATE TABLE users (id TEXT PRIMARY KEY, name TEXT, created_at INTEGER);
CREATE TABLE matches (id TEXT PRIMARY KEY, started_at INTEGER, ended_at INTEGER, winner TEXT, team_size INTEGER, impostors INTEGER);
CREATE TABLE match_players (match_id TEXT, user_id TEXT, role TEXT, won INTEGER);
CREATE TABLE reports (id TEXT PRIMARY KEY, reporter_id TEXT, target_id TEXT, reason TEXT, created_at INTEGER);
```

Suggested R2 layout:

```txt
sfx/click.ogg
sfx/type-1.ogg
sfx/vote-confirm.ogg
sfx/win.ogg
sfx/lose.ogg
music/menu-loop.ogg
music/gameplay-loop.ogg
avatars/cosmetics/*.webp
```

Bind them in `wrangler.jsonc` when needed:

```jsonc
"d1_databases": [{ "binding": "DB", "database_name": "impostor-word-arena", "database_id": "..." }],
"r2_buckets": [{ "binding": "ASSETS", "bucket_name": "impostor-word-arena-assets" }]
```

## Security model

- The server is authoritative.
- Clients receive sanitized state.
- Room passwords are hashed and never returned to clients.
- Private rooms are excluded from KV lobby listings.
- Votes are accepted only during the vote phase.
- Clues are accepted only from the active turn player.
- Impostor/normal roles are assigned server-side.
- Results are computed server-side.

## Next product upgrades

- Add account login and reconnect identity.
- Replace synthetic audio with R2-hosted mastered sound effects.
- Add cosmetic unlocks and profile banners.
- Add party invite links.
- Add spectator mode.
- Add mobile haptics.
- Add in-room voice chat through a dedicated RTC provider.
